package at.eder.wirtschaftstagmobileapp.ui.participation

import androidx.fragment.app.Fragment

class ParticipationCreateFragment : Fragment() {
}