package at.eder.wirtschaftstagmobileapp.ui.mail

import androidx.fragment.app.Fragment

class MailCreateFragment : Fragment() {
}