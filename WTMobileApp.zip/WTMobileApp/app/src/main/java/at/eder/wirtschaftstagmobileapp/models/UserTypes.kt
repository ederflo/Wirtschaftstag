package at.eder.wirtschaftstagmobileapp.models

enum class UserTypes {
    pupil, responsible, admin
}